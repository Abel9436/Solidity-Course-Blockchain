// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Contract {
    bool public a = true;
    bool public b = false;
}